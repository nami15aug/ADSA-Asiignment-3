#include <bits/stdc++.h>
using namespace std;

void cut_vertices_utility(vector<int> adj[], int u, bool visited[],
                          int discovery[], int low[], int& time, int parent,
                          bool is_cut_vertex[])
{
    /* Count of children in DFS Tree */
    int children = 0;

    /* Mark the current node as visited */
    visited[u] = true;

    /* Initialize discovery time and low value */
    discovery[u] = low[u] = ++time;

    /* Go through all vertices adjacent to this */
    for (auto v : adj[u])
    {
        /* If v is not visited yet, then make it a child of u in DFS tree and recur for it */
        if (!visited[v])
        {
            children++;
            cut_vertices_utility(adj, v, visited, discovery, low, time, u, is_cut_vertex);

            /* Check if the subtree rooted with v has a connection to one of the ancestors of u */
            low[u] = min(low[u], low[v]);

            /* If u is not root and low value of one of its child is more than discovery value of u */
            if (parent != -1 && low[v] >= discovery[u])
                is_cut_vertex[u] = true;
        }

        /* Update low value of u for parent function calls */
        else if (v != parent)
            low[u] = min(low[u], discovery[v]);
    }

    /* If u is root of DFS tree and has two or more children */
    if (parent == -1 && children > 1)
        is_cut_vertex[u] = true;
}

void cut_vertex(vector<int> adj[], int V)
{
    int discovery[V] = { 0 };
    int low[V];
    bool visited[V] = { false };
    bool is_cut_vertex[V] = { false };
    int time = 0, par = -1;

    for (int u = 0; u < V; u++)
    {
        if (!visited[u])
        {
            cut_vertices_utility(adj, u, visited, discovery, low,
                time, par, is_cut_vertex);
        }

    }

    /* Printing the cut_vertices */
    for (int u = 0; u < V; u++)
    {
        if (is_cut_vertex[u] == true)
        {
            cout << u << " ";
        }
    }
}

/* Utility function to add an edge */
void addEdge(vector<int> adj[], int u, int v)
{
    adj[u].push_back(v);
    adj[v].push_back(u);
}

int main()
{
    cout << "Cut Vertices are \n";
    int V = 5;
    vector<int> adj1[V];
    addEdge(adj1, 1, 0);
    addEdge(adj1, 0, 2);
    addEdge(adj1, 2, 1);
    addEdge(adj1, 0, 3);
    addEdge(adj1, 3, 4);
    cut_vertex(adj1, V);

    return 0;
}
